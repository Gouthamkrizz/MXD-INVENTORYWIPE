local QBCore = nil
local ESX = nil

-- Framework Detection
if Config.Framework == "auto" then
    if GetResourceState("qb-core") == "started" then
        Config.Framework = "qbcore"
    elseif GetResourceState("es_extended") == "started" then
        Config.Framework = "esx"
    end
end

if Config.Framework == "qbcore" then
    QBCore = exports['qb-core']:GetCoreObject()
elseif Config.Framework == "esx" then
    ESX = exports["es_extended"]:getSharedObject()
end

-- Inventory Detection
if Config.Inventory == "auto" then
    if GetResourceState("ox_inventory") == "started" then
        Config.Inventory = "ox"
    elseif GetResourceState("qs-inventory") == "started" then
        Config.Inventory = "qs"
    elseif GetResourceState("qb-inventory") == "started" or GetResourceState("lj-inventory") == "started" or GetResourceState("ps-inventory") == "started" then
        Config.Inventory = "qb"
    elseif Config.Framework == "esx" then
        Config.Inventory = "esx"
    elseif Config.Framework == "qbcore" then
        Config.Inventory = "qb"
    end
end

-- Helper Function to Check Permissions and Get Player
local function IsAdmin(source)
    if Config.Framework == "qbcore" then
        return QBCore.Functions.HasPermission(source, Config.AdminGroup) or IsPlayerAceAllowed(source, 'command')
    elseif Config.Framework == "esx" then
        local xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer then
            local group = xPlayer.getGroup()
            return group == Config.AdminGroup or group == 'superadmin' or group == 'owner'
        end
    end
    return false
end

-- Wipe Function
local function WipeInventory(targetId)
    local success = false

    if Config.Inventory == "ox" then
        -- ox_inventory (Works for both ESX and QBCore if bridged)
        if exports.ox_inventory:ClearInventory(targetId) then
            success = true
        end
    elseif Config.Inventory == "qs" then
        -- qs-inventory
        if GetResourceState("qs-inventory") == "started" then
            -- Try export first
            pcall(function()
                exports['qs-inventory']:ClearInventory(targetId)
                success = true
            end)
        end
    elseif Config.Inventory == "qb" then
        -- qb-inventory / lj-inventory / ps-inventory
        if Config.Framework == "qbcore" and QBCore then
            local Player = QBCore.Functions.GetPlayer(targetId)
            if Player then
                Player.Functions.ClearInventory()
                -- Ensure database save if needed
                Player.Functions.Save()
                success = true
            end
        end
    elseif Config.Inventory == "esx" then
        -- Default ESX Inventory
        if Config.Framework == "esx" and ESX then
            local xPlayer = ESX.GetPlayerFromId(targetId)
            if xPlayer then
                if xPlayer.getInventory then
                    for k, v in ipairs(xPlayer.getInventory()) do
                        if v.count > 0 then
                            xPlayer.removeInventoryItem(v.name, v.count)
                        end
                    end
                    success = true
                end
            end
        end
    end

    -- Fallback/Safety: If no success yet and we are on qbcore, try standard clear again
    if not success and Config.Framework == "qbcore" and QBCore then
        local Player = QBCore.Functions.GetPlayer(targetId)
        if Player then
            Player.Functions.ClearInventory()
            success = true
        end
    end

    return success
end

-- Command Registration
RegisterCommand(Config.CommandName, function(source, args, rawCommand)
    local src = source

    -- Console check (console is always admin)
    if src ~= 0 and not IsAdmin(src) then
        TriggerClientEvent('chat:addMessage', src, {
            color = { 255, 0, 0 },
            multiline = true,
            args = { "System", Config.Messages.NoPermission }
        })
        return
    end

    local targetId = tonumber(args[1])

    if not targetId then
        if src ~= 0 then
            TriggerClientEvent('chat:addMessage', src, {
                color = { 255, 255, 0 },
                multiline = true,
                args = { "System", Config.Messages.Usage }
            })
        else
            print(Config.Messages.Usage)
        end
        return
    end

    local success = WipeInventory(targetId)

    if success then
        local msg = string.format(Config.Messages.Success, targetId)
        if src ~= 0 then
            TriggerClientEvent('chat:addMessage', src, {
                color = { 0, 255, 0 },
                multiline = true,
                args = { "System", msg }
            })
        else
            print(msg)
        end
    else
        local msg = Config.Messages.PlayerNotFound
        if src ~= 0 then
            TriggerClientEvent('chat:addMessage', src, {
                color = { 255, 0, 0 },
                multiline = true,
                args = { "System", msg }
            })
        else
            print(msg)
        end
    end
end, false)
