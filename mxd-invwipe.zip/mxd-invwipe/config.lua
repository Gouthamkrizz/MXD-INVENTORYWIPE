Config = {}

-- Framework Configuration
-- Options: "auto", "qbcore", "esx"
Config.Framework = "auto"

-- Inventory Configuration
-- Options: "auto", "ox", "qs", "qb", "esx" (default esx menu)
Config.Inventory = "auto"

-- Command Configuration
Config.CommandName = "invwipe" -- Command to use (e.g., /invwipe)

-- Permissions Configuration
-- For QBCore: specific permission level or 'god'
-- For ESX: user group (e.g., 'admin', 'superadmin')
Config.AdminGroup = "admin"

-- Messages
Config.Messages = {
    Success = "Inventory has been wiped for player %s.",
    Error = "An error occurred while wiping inventory.",
    NoPermission = "You do not have permission to use this command.",
    PlayerNotFound = "Player not found.",
    InvalidId = "Invalid player ID.",
    Usage = "Usage: /invwipe [playerId]"
}
