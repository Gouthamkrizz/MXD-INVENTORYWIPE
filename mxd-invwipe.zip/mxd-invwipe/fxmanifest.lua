fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'MXD'
description 'Multi-framework Inventory Wipe Command'
version '1.0.0'

shared_script 'config.lua'
server_script 'server.lua'
